import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.net.InetSocketAddress;

/**
 * Created by qxqs1 on 2016/10/7.
 */
public class MyHttpServer
{
    public static void main(String args[])
    {

        try
        {
            HttpServer server = null;
            server = HttpServer.create(new InetSocketAddress(8000), 0);

            server.createContext("/test", new MyHandler());

            //! 必须先使用 JNI 加载 so 动态库，否则，VisualGDB 调试的模块列表无法找到对应的模块
            server.createContext("/jni", new MyJniHandler());

            //! 先使用 JNA 加载 so 时，或仅使用 JNA 加载 so 时，VisualGDB 调试的模块列表无法找到对应的模块
            server.createContext("/jna", new MyJnaHandler());

            server.setExecutor(null); // creates a default executor
            server.start();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
