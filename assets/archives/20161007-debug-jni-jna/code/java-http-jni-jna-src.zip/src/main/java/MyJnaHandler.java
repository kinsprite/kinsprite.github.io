import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Platform;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.PointerByReference;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import static javax.imageio.ImageIO.read;

/**
 * Created by qxqs1 on 2016/10/7.
 */
public class MyJnaHandler implements HttpHandler
{
    static CMyJnaLibrary PE_CMyJnaLibrary = (CMyJnaLibrary)
            Native.loadLibrary("myjna", CMyJnaLibrary.class);


    public interface CMyJnaLibrary extends Library
    {
//       CMyJnaLibrary INSTANCE = (CMyJnaLibrary)
//                Native.loadLibrary("myjna", CMyJnaLibrary.class);

        void response(String inStr, PointerByReference outStr);
        void deleteOutString(Pointer pointer);
    }

    public void handle(HttpExchange t) throws IOException
    {
        PointerByReference outJna = new PointerByReference();

        try
        {
            String inJna = "This is the input for JNA.\n";
            PE_CMyJnaLibrary.response(inJna, outJna);

            String response = outJna.getValue().getString(0);

            t.sendResponseHeaders(200, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
        finally
        {
            PE_CMyJnaLibrary.deleteOutString(outJna.getValue());
        }
    }
}
