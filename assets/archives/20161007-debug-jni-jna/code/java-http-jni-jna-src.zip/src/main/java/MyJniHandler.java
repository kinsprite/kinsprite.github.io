import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Platform;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.PointerByReference;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import static javax.imageio.ImageIO.read;

/**
 * Created by qxqs1 on 2016/10/7.
 */
public class MyJniHandler implements HttpHandler
{
    public native int echoHello(String call);

    static
    {
        System.loadLibrary("myjna");
    }


    public void handle(HttpExchange t) throws IOException
    {
        String inStr = "This is the input for jni.\n";
        String response = "Response: " + echoHello(inStr) + "\n";

        t.sendResponseHeaders(200, response.length());
        OutputStream os = t.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }
}
