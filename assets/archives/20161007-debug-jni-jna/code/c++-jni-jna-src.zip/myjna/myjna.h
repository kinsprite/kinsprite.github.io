#pragma once

#ifdef __cplusplus
extern "C" {
#endif

	__attribute__((visibility("default"))) void response(const char *inStr, char **outStr);
	__attribute__((visibility("default"))) void deleteOutString(char *str);

#ifdef __cplusplus
}
#endif
