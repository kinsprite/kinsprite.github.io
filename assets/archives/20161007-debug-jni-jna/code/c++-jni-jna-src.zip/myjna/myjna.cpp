#include "myjna.h"

#include "jni_md.h"
#include "jni.h"

#include <string>
#include <algorithm>
#include <iostream>

#ifdef __cplusplus
extern "C"
{
#endif

	__attribute__((visibility("default"))) void response(const char *inStr, char **outStr)
	{
		std::string s = inStr;
		s += "This is the out string from JNA.\n";
		*outStr = new char[1024];
		std::copy(s.begin(), s.end(), *outStr);
	}
	
	__attribute__((visibility("default"))) void deleteOutString(char *str)
	{
		delete[] str;
	}
	
	JNIEXPORT jint JNICALL Java_MyJniHandler_echoHello(JNIEnv *env, jobject obj, jstring call)
	{
		std::cout << "JNI MyJniHandler_echoHello()" << std::endl;
		return 100110;
	}

#ifdef __cplusplus
}
#endif
